fileMeta myFiles[15] = 
{
  { 279200      , "2297aacd9380d9b438490d6002bc83be", "firmware_example_esp32" },
  { 120188      , "42ad7a973640e95f1cbfbd7b45a94ef1", "firmware_example_esp32.gz" },
  { 266496      , "e5956fa1f561e8e4657bfcdd2d92b447", "firmware_example_esp8266" },
  { 196204      , "774b98d8880c82a60e14040a76f636f7", "firmware_example_esp8266.gz" },
  { 145783      , "0650b35fbbaff218f46388764453d951", "gz_example.jpg" },
  { 133877      , "815f9a5dd4ae37915e9842b4229181ab", "gz_example.jpg.gz" },
  { 31624       , "9ba1fdface48283cbf3bedfd1046a629", "mgmadchat.jpg" },
  { 145783      , "0650b35fbbaff218f46388764453d951", "Miaou-Goldwyn-Mayer.jpg" },
  { 179712      , "f5b3c789ceb322f70dc28ff61efb9529", "tar_example.tar" },
  { 16787       , "7f37ba4ed2bb127a8f9e4d9ee6e3c19e", "targz_example.tar.gz" },
  { 48          , "44ffda4b76b4fd0b13b6a1cf84003488", "zombo.com/css/blah.css" },
  { 4701        , "28913d007a7127a5b009e8584640717a", "zombo.com/img/logo.png" },
  { 7172        , "cf1f1f596ab7a726334ffcee1100a912", "zombo.com/img/spinner.png" },
  { 2040        , "808a446d1885a65202fc8f7dc5fb7341", "zombo.com/index.html" },
  { 7925        , "22ed447b5be77f1bd7a8c3f08f9b702a", "zombo.com/snd/inrozxa.swf" },
};
packageMeta myPackage = 
{
  nullptr, 15, myFiles
};
