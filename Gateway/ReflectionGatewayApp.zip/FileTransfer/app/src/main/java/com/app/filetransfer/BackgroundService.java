package com.app.filetransfer;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothSocket;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.PowerManager;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

import static android.bluetooth.BluetoothProfile.STATE_CONNECTED;
import static com.app.filetransfer.App.CHANNEL_ID;

public class BackgroundService extends Service {

    private String TAG = "ESP-BT";

    static final int CLASSIC_STATE_LISTENING = 1;
    static final int CLASSIC_STATE_CONNECTING = 2;
    static final int CLASSIC_STATE_CONNECTED = 3;
    static final int CLASSIC_STATE_CONNECTION_FAILED = 4;
    static final int CLASSIC_STATE_MESSAGE_RECEIVED = 5;
    static final int CLASSIC_STATE_DISCONNECTED = 6;

    UUID Service_UUID = UUID.fromString("6E400001-B5A3-F393-E0A9-E50E24DCCA9E");
    UUID Characteristic_UUID_RX = UUID.fromString("6E400002-B5A3-F393-E0A9-E50E24DCCA9E");
    UUID Characteristic_UUID_TX = UUID.fromString("6E400003-B5A3-F393-E0A9-E50E24DCCA9E");
    UUID Descriptor_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    Boolean rcv_file = false;
    Boolean send_file = false;

    BluetoothManager mbluetoothManager;
    BluetoothAdapter mbluetoothAdapter;
    BluetoothLeScanner mbluetoothLeScanner;
    BluetoothDevice mdevice = null;
    BluetoothGatt mgatt = null;
    BluetoothGattCharacteristic write_characteristic = null;

    Boolean ble_connected = false;
    Client_class client_class = null;
    sendReceive sendReceive = null;
    fetchURL fetchURLObj = null;
    fetchFile fetchFileObj = null;

    Boolean start_send = false;

    BufferedOutputStream fos = null;

    double expect_bytes = 0, total_bytes = 0;

    String url_data = "";
    String file_url = "";

    String urlString = "https://virtserver.swaggerhub.com/venkatesan.e/askForCommand/1.0.0/askForCommand?deviceId=1234";

    public static BackgroundService cinstance = null;
    public Boolean isStarted = false;

    PowerManager.WakeLock screenLock = null;

    public static final long INTERVAL=5000;
    private Handler mHandler=new Handler();
    private Timer mTimer=null;

    private class TimeDisplayTimerTask extends TimerTask {
        @Override
        public void run() {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    Log.i("FILE SERVICE", "RUNNING IN BACKGROUND");
                }
            });
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        cinstance = this;
        if(mTimer!=null)
            mTimer.cancel();
        else
            mTimer=new Timer();
        mTimer.scheduleAtFixedRate(new TimeDisplayTimerTask(),0,INTERVAL);

        mbluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mbluetoothAdapter = mbluetoothManager.getAdapter();

        Intent notificationIntent = new Intent(this, MainActivity.class);
        notificationIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("File Transfer Service")
                .setContentText("Click Here to open automate service")
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .build();

        startForeground(1, notification);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        cinstance = this;
        String type = intent.getExtras().getString("type");
        if (type.equals("start")){
            Log.e("Background Service : ", "Starting Service");
            startService();
        }
        else if (type.equals("stop")){
            Log.e("Background Service : ", "Stopping Service");
            stopService();
        }
        return START_STICKY;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.e("Background Service : ", "Task Unbind");
        return super.onUnbind(intent);
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        Log.e("Background Service : ", "Task Removed");
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mTimer.cancel();
        cinstance = null;
        Log.e("Background Service : ", "Destroyed");
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void startService(){
        if (isStarted) return;
        IntentFilter filter1 = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
        registerReceiver(mBroadcastReceiver1, filter1);
        isStarted = true;
        mbluetoothLeScanner = mbluetoothAdapter.getBluetoothLeScanner();
        mbluetoothLeScanner.startScan(mscanCallback);
    }

    private void stopService(){
        unregisterReceiver(mBroadcastReceiver1);
        isStarted = false;
        try {
            if (fos != null){
                fos.close();
            }
            if (client_class != null){
                client_class.close();
            }
            rcv_file = false;
            send_file = false;
            if (mgatt != null){
                mgatt.disconnect();
            }
            if (mbluetoothLeScanner != null){
                mbluetoothLeScanner.stopScan(mstopscanCallback);
                mbluetoothLeScanner = null;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        stopForeground(true);
        stopSelf();
    }

    public void add_status(String msg){
        Log.i(TAG, msg);
        /*if (MainActivity.cinstance != null){
            MainActivity.cinstance.add_status(msg);
        }*/
    }

    void send_cmd(String cmd){
        if (mgatt != null){
            write_characteristic.setValue(cmd.getBytes());
            mgatt.writeCharacteristic(write_characteristic);
        }
    }

    Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            switch (msg.what){
                case CLASSIC_STATE_LISTENING:
                    add_status("LISTENING");
                    break;
                case CLASSIC_STATE_CONNECTING:
                    add_status("CONNECTING");
                    break;
                case CLASSIC_STATE_CONNECTED:
                    add_status("CLASSIC CONNECTED");
                    break;
                case CLASSIC_STATE_DISCONNECTED:
                    add_status("CLASSIC DISCONNECTED");
                    if (client_class != null){
                        client_class.close();
                        client_class.interrupt();
                        client_class = null;
                    }
                    break;
                case CLASSIC_STATE_CONNECTION_FAILED:
                    add_status("CLASSIC CONNECTION FAILED");
                    send_file = false;
                    start_send = false;
                    if (client_class != null){
                        client_class.close();
                        client_class.interrupt();
                        client_class = null;
                    }
                    if (sendReceive != null){
                        sendReceive.close();
                        sendReceive.interrupt();
                        sendReceive = null;
                    }
                    if (fetchURLObj != null){
                        fetchURLObj.interrupt();
                        fetchURLObj = null;
                    }
                    if(fetchFileObj != null){
                        fetchFileObj.interrupt();
                        fetchFileObj = null;
                    }
                    if (mgatt != null){
                        mgatt.disconnect();
                        mgatt = null;
                    }
                    break;
                case CLASSIC_STATE_MESSAGE_RECEIVED:
                    byte[] readBuff = (byte[])msg.obj;
                    add_status("CLASSIC MESSAGE RECEIVED");
                    break;
            }
            return true;
        }
    });

    private final ScanCallback mscanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            if (result.getDevice().getName() != null) add_status("Scanning.... " + result.getDevice().getName());
            if (mdevice == null && result.getDevice().getName() != null && result.getDevice().getName().equals("ESP32")){
                add_status("Device : " + result.getDevice().getName());
                add_status("Device Address : " + result.getDevice().getAddress());
                mdevice = mbluetoothAdapter.getRemoteDevice(result.getDevice().getAddress());
                if(mgatt != null){
                    mgatt.disconnect();
                    mgatt = null;
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    mgatt = mdevice.connectGatt(BackgroundService.this, false, mgattCallback, BluetoothDevice.TRANSPORT_LE);
                } else {
                    mgatt = mdevice.connectGatt(BackgroundService.this, false, mgattCallback);
                }
            }
        }
    };

    private final ScanCallback mstopscanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            super.onScanResult(callbackType, result);
        }
    };

    private final BluetoothGattCallback mgattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            if (newState == STATE_CONNECTED) {
                mbluetoothLeScanner.stopScan(mstopscanCallback);
                add_status("BLE Connected");
                gatt.discoverServices();
                ble_connected = true;
            } else {
                ble_connected = false;
                add_status("BLE Disconnected");
                mdevice = null;
                if (mgatt != null){
                    gatt.disconnect();
                    mgatt.disconnect();
                    mgatt = null;
                }
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            add_status("Service Discovered");
            write_characteristic = gatt.getService(Service_UUID).getCharacteristic(Characteristic_UUID_RX);
            write_characteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
            BluetoothGattCharacteristic mcharacteristic = gatt.getService(Service_UUID).getCharacteristic(Characteristic_UUID_TX);
            gatt.setCharacteristicNotification(mcharacteristic, true);
            BluetoothGattDescriptor descriptor = mcharacteristic.getDescriptor(Descriptor_UUID);
            descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
            gatt.writeDescriptor(descriptor);
            if (fetchURLObj == null){
                fetchURLObj = new fetchURL();
                fetchURLObj.start();
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            byte readBuff[] = characteristic.getValue();
            String tmp = new String(readBuff, StandardCharsets.UTF_8);
            if (tmp.equals("completed")) {
                if (send_file) {
                    if (client_class != null){
                        client_class.close();
                        client_class.interrupt();
                        client_class = null;
                    }
                    if (sendReceive != null){
                        sendReceive.close();
                        sendReceive.interrupt();
                        sendReceive = null;
                    }
                    if (fetchURLObj != null){
                        fetchURLObj.interrupt();
                        fetchURLObj = null;
                    }
                    if(fetchFileObj != null){
                        fetchFileObj.interrupt();
                        fetchFileObj = null;
                    }
                    send_file = false;
                    start_send = false;
                    add_status("Data Send Successfully");
                }
            }else if(tmp.equals("start_download")){
                start_send = true;
            }else {
                add_status("Value = " + tmp);
            }
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            byte readBuff[] = characteristic.getValue();
            String tmp = new String(readBuff, StandardCharsets.UTF_8);
            add_status(tmp);
            if (tmp.equals("download")) {
                send_file = true;
                if (client_class == null){
                    client_class = new Client_class(mdevice);
                    client_class.start();
                }
            }
        }

        @Override
        public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
            add_status("MTU Changed to : " + Integer.toString(mtu));
        }
    };

    private class Client_class extends Thread{
        private BluetoothDevice device;
        private BluetoothSocket socket;
        public Client_class(BluetoothDevice device1){
            device = device1;
            try {
                socket = device.createInsecureRfcommSocketToServiceRecord(MY_UUID);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void run(){
            try {
                socket.connect();
                Message message = Message.obtain();
                message.what = CLASSIC_STATE_CONNECTED;
                handler.sendMessage(message);
                if (sendReceive == null){
                    sendReceive = new sendReceive(socket);
                    sendReceive.start();
                }
            } catch (IOException e) {
                e.printStackTrace();
                Message message = Message.obtain();
                message.what = CLASSIC_STATE_CONNECTION_FAILED;
                try {
                    socket.close();
                    close();
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
                handler.sendMessage(message);
            }
        }

        @SuppressLint("SetTextI18n")
        public void close(){
            if(socket.isConnected()){
                try {
                    sendReceive.close();
                    socket.close();
                    Message message = Message.obtain();
                    message.what = CLASSIC_STATE_DISCONNECTED;
                    handler.sendMessage(message);
                } catch (IOException e) {
                    e.printStackTrace();
                    add_status("CANNOT DISCONNECT DEVICE");
                }
            }
        }

        public boolean isConnected(){
            return socket.isConnected();
        }
    }

    private class sendReceive extends Thread{
        private final BluetoothSocket bluetoothSocket;
        private final InputStream inputStream;
        private final OutputStream outputStream;
        private boolean run_state = true;
        private BufferedOutputStream bos = null;

        private sendReceive(BluetoothSocket socket) {
            bluetoothSocket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            try {
                tmpIn = bluetoothSocket.getInputStream();
                tmpOut = bluetoothSocket.getOutputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }

            inputStream = tmpIn;
            outputStream = tmpOut;
        }

        private byte lCRC8(byte arr[], int len){
            byte crc = 0;
            for(int i=0; i<len; i++){
                crc ^= arr[i];
            }
            return crc;
        }

        public void run(){
            byte[] buffer = new byte[1024];
            int bytes;

            while (run_state && bluetoothSocket.isConnected()){
                if (!bluetoothSocket.isConnected()){
                    add_status("CLASSIC DISCONNECTED");
                    run_state = false;
                    if (!client_class.isConnected()){
                        client_class.close();
                        close();
                    }
                }
                try {
                    bytes = inputStream.read(buffer);
                    handler.obtainMessage(CLASSIC_STATE_MESSAGE_RECEIVED, bytes, -1, buffer).sendToTarget();
                } catch (IOException e) {
                    run_state = false;
                    e.printStackTrace();
                }
            }
        }

        public void write(byte[] bytes, int length){
            try {
                outputStream.write(bytes, 0, length);
                outputStream.flush();
            } catch (IOException e) {
                Message message = Message.obtain();
                message.what = CLASSIC_STATE_CONNECTION_FAILED;
                handler.sendMessage(message);
                e.printStackTrace();
            }
        }

        public boolean isConnected(){
            return run_state;
        }

        public void close(){
            run_state = false;
            try {
                inputStream.close();
                outputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    class fetchURL extends Thread{
        @Override
        public void run() {
            try {
                URL url = new URL(urlString);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                String line;

                while ((line = bufferedReader.readLine()) != null){
                    url_data = url_data + line;
                }

                if (!url_data.isEmpty()){
                    JSONArray array = new JSONArray(url_data);
                    JSONObject jsonObject = array.getJSONObject(0);
                    file_url = jsonObject.getString("url");
                    Log.e(TAG, file_url);
                    if (fetchFileObj == null){
                        fetchFileObj = new fetchFile();
                        fetchFileObj.start();
                    }
                }
            } catch (MalformedURLException e) {
                add_status("Error : " + e);
                e.printStackTrace();
            } catch (IOException | JSONException e) {
                add_status("Error : " + e);
                e.printStackTrace();
            }
        }
    }

    class fetchFile extends Thread{
        @Override
        public void run() {
            try {
                URL url = new URL(file_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.connect();

                add_status("HTTP Response : " + httpURLConnection.getResponseCode());

                InputStream inputStream = new BufferedInputStream(url.openStream(), 8192);

                String fileName = file_url.substring( file_url.lastIndexOf('/')+1);
                String file_size;
                add_status("File Name : " + fileName);

                Date date1 = Calendar.getInstance().getTime();

                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                    Long file_length = httpURLConnection.getContentLengthLong();
                    add_status("File Long Length : " + file_length);
                    add_status("File Length : " + file_length/(1024*1024) + " MB");
                    file_size = Long.toString(file_length);
                }
                else {
                    int file_length = httpURLConnection.getContentLength();
                    add_status("File Int Length : " + file_length);
                    add_status("File Int Length : " + file_length/(1024*1024) + " MB");
                    file_size = Integer.toString(file_length);
                }
                send_cmd("fn:" + fileName + " fl:" + file_size);
                Thread.sleep(500);
                send_cmd("download");
                Thread.sleep(500);
                add_status("Connecting...");
                while (!start_send){
                    Thread.sleep(500);
                }
                expect_bytes = Double.parseDouble(file_size);
                total_bytes = 0;
                add_status("Total Size : " + expect_bytes);
                while (client_class == null){
                    Thread.sleep(500);
                }
                while(!client_class.isConnected()){
                    Thread.sleep(500);
                }
                byte[] buffer = new byte[4096];
                int bufferLength = 0;

                while ( (bufferLength = inputStream.read(buffer)) != -1 && start_send){
                    if (!ble_connected){
                        Log.e(TAG, "CLIENT DISCONNECTED DURING FILE TRANSFER");
                        client_class.close();
                        if (fetchURLObj != null){
                            fetchURLObj.interrupt();
                            fetchURLObj = null;
                        }
                        if (fetchFileObj != null){
                            fetchFileObj.interrupt();
                            fetchFileObj = null;
                        }
                        send_file = false;
                        start_send = false;
                        break;
                    }
                    sendReceive.write(buffer, bufferLength);
                }
                inputStream.close();
                Thread.sleep(300);
                if (ble_connected){
                    send_cmd("finish");
                }
                SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
                String formattedDate = df.format(date1);
                add_status("Start Time : " + formattedDate);
                Date date2 = Calendar.getInstance().getTime();
                formattedDate = df.format(date2);
                add_status("End Time : " + formattedDate);
                long millis = date2.getTime() - date1.getTime();
                add_status("Total Time : " + (millis/1000));
            } catch (MalformedURLException e) {
                add_status("Error : " + e);
                e.printStackTrace();
            } catch (IOException e) {
                add_status("Error : " + e);
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private final BroadcastReceiver mBroadcastReceiver1 = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            if (action.equals(BluetoothAdapter.ACTION_STATE_CHANGED)) {
                final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR);
                switch(state) {
                    case BluetoothAdapter.STATE_OFF:
                    case BluetoothAdapter.STATE_TURNING_OFF:
                        Intent intent1 = new Intent(BackgroundService.this, MainActivity.class);
                        intent1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent1);
                        break;
                }
            }
        }
    };
}
