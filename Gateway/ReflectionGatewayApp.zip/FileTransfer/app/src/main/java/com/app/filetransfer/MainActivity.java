package com.app.filetransfer;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothSocket;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

import static android.bluetooth.BluetoothProfile.STATE_CONNECTED;

public class MainActivity extends AppCompatActivity {

    public static MainActivity cinstance = null;

    private String TAG = "ESP-BT";

    BluetoothManager mbluetoothManager;
    BluetoothAdapter mbluetoothAdapter;

    static final int REQUEST_ENABLE_BT = 0;

    Switch bluetooth, connect;
    Button send_file_btn;
    TextView status;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cinstance = this;
        bluetooth = findViewById(R.id.switch1);
        connect = findViewById(R.id.switch2);
        status = findViewById(R.id.status);
        send_file_btn = findViewById(R.id.send_file_btn);

        status.setMovementMethod(new ScrollingMovementMethod());
        status.setText("Start\n");

        mbluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mbluetoothAdapter = mbluetoothManager.getAdapter();

        if (isPermissionGranted() && mbluetoothAdapter != null && mbluetoothAdapter.isEnabled()){
            bluetooth.setChecked(true);
        }
        else if (mbluetoothAdapter == null || !mbluetoothAdapter.isEnabled()){
            Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(intent, REQUEST_ENABLE_BT);
        }

        /*if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent();
            String packageName = getPackageName();
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                intent.setAction(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + packageName));
                startActivity(intent);
            }
        }*/

        /*try {
            Intent intent = new Intent();
            String manufacturer = android.os.Build.MANUFACTURER;
            if ("xiaomi".equalsIgnoreCase(manufacturer)) {
                intent.setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"));
            } else if ("oppo".equalsIgnoreCase(manufacturer)) {
                intent.setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"));
            } else if ("vivo".equalsIgnoreCase(manufacturer)) {
                intent.setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"));
            } else if("oneplus".equalsIgnoreCase(manufacturer)) {
                intent.setComponent(new ComponentName("com.oneplus.security", "com.oneplus.security.chainlaunch.view.ChainLaunchAppListAct‌​ivity")); }

            List<ResolveInfo> list = this.getPackageManager().queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
            if  (list.size() > 0) {
                this.startActivity(intent);
            }
        } catch (Exception e) {
           Log.e(TAG,e.toString());
        }*/

        if (BackgroundService.cinstance != null){
            connect.setChecked(true);
        }

        bluetooth.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    if (mbluetoothAdapter == null || !mbluetoothAdapter.isEnabled()){
                        Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                        startActivityForResult(intent, REQUEST_ENABLE_BT);
                    }
                    else {
                        show_toast("Bluetooth Already ON");
                    }
                }
                else {
                    if (mbluetoothAdapter.isEnabled()){
                        show_toast("Turning Off Bluetooth");
                        mbluetoothAdapter.disable();
                    }
                    else {
                        show_toast("Bluetooth Already OFF");
                    }
                }
            }
        });

        connect.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    Intent serviceIntent = new Intent(MainActivity.this, BackgroundService.class);
                    serviceIntent.putExtra("type", "start");
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
                        ContextCompat.startForegroundService(MainActivity.this, serviceIntent);
                    }
                    else {
                        startService(serviceIntent);
                    }
                    moveTaskToBack(true);
                }
                else {
                    Intent serviceIntent = new Intent(MainActivity.this, BackgroundService.class);
                    serviceIntent.putExtra("type", "stop");
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
                        ContextCompat.startForegroundService(MainActivity.this, serviceIntent);
                    }
                    else {
                        startService(serviceIntent);
                    }
                }
            }
        });
    }

    public void send_file_fun(View view) {
        status.append("getting data\n");
    }

    public void add_status(String msg){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                status.append(msg + "\n");
            }
        });
    }

    private void show_toast(String msg){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void buttons_enable(Boolean en){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (en)
                {
                    send_file_btn.setEnabled(true);
                    send_file_btn.getBackground().setColorFilter(null);
                }
                else {
                    send_file_btn.setEnabled(false);
                    send_file_btn.getBackground().setColorFilter(Color.GRAY, PorterDuff.Mode.MULTIPLY);
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        switch (requestCode){
            case REQUEST_ENABLE_BT:
                if (resultCode == RESULT_OK){
                    show_toast("Bluetooth is On");
                    bluetooth.setChecked(true);
                }
                else {
                    show_toast("Can't Turn on Bluetooth");
                    bluetooth.setChecked(false);
                }
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    public boolean isPermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                Log.v(TAG,"Permission is granted1");
                return true;
            } else {

                Log.v(TAG,"Permission is revoked1");
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
                return false;
            }
        }
        else {
            Log.v(TAG,"Permission is granted1");
            return true;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        int total_result = 0;
        if (requestCode == 1)
        {
            for (int results:grantResults){
                if (grantResults[results] == PackageManager.PERMISSION_GRANTED){
                    Log.v(TAG,"Permission: "+permissions[results]+ " was "+ grantResults[results]);
                    total_result = total_result + grantResults[results];
                }
                else {
                    Log.v(TAG,"Permission: "+permissions[results]+ " was "+ grantResults[results]);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            show_toast("Required Permissions Not Granted");
                            MainActivity.this.finish();
                        }
                    });
                }
            }

            if (total_result == 0 && mbluetoothAdapter != null && mbluetoothAdapter.isEnabled()){
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        bluetooth.setChecked(true);
                    }
                });
            }
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e("Main Activity : ", "Destroyed");
    }
}