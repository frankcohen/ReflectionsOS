#include "Print.h"
/*
  Reflections is a hardware and software platform for building entertaining mobile experiences.

  Repository is at [https://github.com/frankcohen/ReflectionsOS](https://github.com/frankcohen/ReflectionsOS/)
  Includes board wiring directions, server side components, examples, support

  Licensed under GPL v3 Open Source Software
  (c) Frank Cohen, All rights reserved. fcohen@starlingwatch.com
  Read the license in the license.txt file that comes with this code.

  Reflections board usees an (LIS3DHTR 3-Axis Accelerometer) to
  identify user gestures with their wrists and to wake the
  processor from sleep.

  Recognizes gestures by moving the Reflections board 

  Repository is at https://github.com/frankcohen/ReflectionsOS
  Includes board wiring directions, server side components, examples, support

  Requires Adafruit LIS3DH library at:
  https://github.com/adafruit/Adafruit_LIS3DH


*/

#include "AccelSensor.h"

Adafruit_LIS3DH myaccel = Adafruit_LIS3DH();

AccelSensor::AccelSensor(){}

void AccelSensor::begin()
{ 
  myc = 0;

  bufferIndex = 0;
  lastTapTime = 0;
  doubleTapDetected = false;
  tapDetectedInSample = false;
  gestureDetected = false;
  lastSampleTime = millis();  // Set it to the current time

  if ( ! myaccel.begin( accelAddress ) ) 
  {
    Serial.println( F( "Could not start accelerometer, stopping" ) );
    while (1) yield();
  }

  myaccel.setRange(LIS3DH_RANGE_8_G);   // 2, 4, 8 or 16 G!
  myaccel.setClick(2, CLICKTHRESHHOLD);

  for (int i = 1; i < BUFFER_SIZE; i++) 
  {
    buffer[i].x = 0;
    buffer[i].y = 0;
    buffer[i].z = 0;
  }
}

float AccelSensor::getXreading() 
{
  return 0;
}

// Sample accelerometer data every 100ms and store it in the buffer

void AccelSensor::sampleData() 
{  
  if ( millis() - lastSampleTime >= SAMPLE_INTERVAL) 
  {
    lastSampleTime = millis();

    // Read accelerometer values

    buffer[bufferIndex].x = myaccel.readFloatAccelX();
    buffer[bufferIndex].y = myaccel.readFloatAccelY();
    buffer[bufferIndex].z = myaccel.readFloatAccelZ();

/*
    if ( myc > 10 ) return;
    myc++;

    for ( int i = 0; i < 100; i++ )
    {
      int currentIndex2 = (bufferIndex - i + BUFFER_SIZE) % BUFFER_SIZE;

      Serial.print( myc );
      Serial.print( ", " );
      Serial.print( currentIndex2 );
      Serial.print( ", " );
      Serial.print( buffer[currentIndex2].x );
      Serial.print( ", " );
      Serial.print( buffer[currentIndex2].y );
      Serial.print( ", " );
      Serial.println( buffer[currentIndex2].z );

    }
*/

    if ( ( buffer[bufferIndex].x == 0 ) && ( buffer[bufferIndex].y == 0 ) && ( buffer[bufferIndex].z == 0 ) ) return;

    // Move the buffer index and wrap it around if it exceeds BUFFER_SIZE
    bufferIndex = (bufferIndex + 1) % BUFFER_SIZE;
  }
}

// Run the gesture sensing algorithm on the buffer

void AccelSensor::runGestureSensing() 
{
  // Example: Calculate average acceleration over the last N samples
  float avgX = 0, avgY = 0, avgZ = 0;

  for (int i = 0; i < BUFFER_SIZE; i++) 
  {
    avgX += buffer[i].x;
    avgY += buffer[i].y;
    avgZ += buffer[i].z;
  }

  avgX /= BUFFER_SIZE;
  avgY /= BUFFER_SIZE;
  avgZ /= BUFFER_SIZE;

  /*
  // Process this data to detect gestures, patterns, or other activities
  Serial.print("Average X: ");
  Serial.print(avgX);
  Serial.print(", Average Y: ");
  Serial.print(avgY);
  Serial.print(", Average Z: ");
  Serial.println(avgZ);
  */

  // Further gesture detection logic can be added here
}

// Detect tap and double tap using differential analysis
void AccelSensor::detectTapAndDoubleTap() {
  // Add tap and double tap detection logic based on the cyclic buffer and differential sampling
  // Call this method periodically, for example, after a sample period or on a separate interrupt

  // Example: Check if there was a significant change in the accelerometer data
  // Here you would use differential analysis to detect tap and double tap
  if (tapDetectedInSample) {
    Serial.println("Tap detected!");
    // Implement double tap detection here...
  }
}

// Clear the buffer (if needed)
void AccelSensor::clearBuffer() {
  for (int i = 0; i < BUFFER_SIZE; i++) {
    buffer[i].x = 0;
    buffer[i].y = 0;
    buffer[i].z = 0;
  }
  bufferIndex = 0;
}

// Invalidate the tap detection if a large gesture is detected
void AccelSensor::invalidateTapIfGestureDetected() {
  if (gestureDetected) {
    Serial.println("Gesture detected. Invalidating tap and double tap.");
    tapDetectedInSample = false;
    doubleTapDetected = false;  // Invalidate double tap as well
  }
}

bool AccelSensor::tapped()
{
  bool result = tapDetectedInSample;
  tapDetectedInSample = false;
  return result;
}

bool AccelSensor::doubletapped()
{
  bool result = doubleTapDetected;
  tapDetectedInSample = false;
  return result;
}

void AccelSensor::detectTapFromBuffer() 
{
  if ( millis() - lastSampleTime >= SAMPLE_INTERVAL) 
  {
    lastSampleTime = millis();

    int increasingCount = 0;          // Counter for consecutive increasing magnitudes
    int decreasingCount = 0;          // Counter for consecutive decreasing magnitudes
    float prevMagnitude = 0, currentMagnitude = 0;
    bool spikeDetected = false;       // Flag to track when a spike is detected
    int currentIndex = 0;
    int prevIndex = 0;
    bool downswing = false;

    tapDetectedInSample = false;

    // Loop through the most recent 10 values in the buffer
    for (int i = 1; i <= numRecentSamples; i++) 
    {
      // Get the current and previous index in the buffer, considering wrapping
      currentIndex = (bufferIndex - i + BUFFER_SIZE) % BUFFER_SIZE;
      prevIndex = (currentIndex - 1 + BUFFER_SIZE) % BUFFER_SIZE;

      // Calculate the magnitude (sqrt of x^2 + y^2 + z^2) for both current and previous readings
      currentMagnitude = sqrt( ( buffer[currentIndex].x * buffer[currentIndex].x ) +
                              ( buffer[currentIndex].y * buffer[currentIndex].y ) +
                              ( buffer[currentIndex].z * buffer[currentIndex].z ) );

      prevMagnitude = sqrt( ( buffer[prevIndex].x * buffer[prevIndex].x ) +
                          ( buffer[prevIndex].y * buffer[prevIndex].y ) +
                          ( buffer[prevIndex].z * buffer[prevIndex].z ) );

      if ( ! downswing )
      {
        if (currentMagnitude > prevMagnitude) {
          increasingCount++;  // Increment if magnitude is increasing

          if ( increasingCount > 2 )
          {
            downswing = true;
          }
        }
        else
        {
          increasingCount = 0;
          decreasingCount = 0;
        }
      }
      else
      {
        if (currentMagnitude < prevMagnitude) 
        {
          decreasingCount++;
        }
        else
        {
          increasingCount = 0;
          decreasingCount = 0;
        }
      }

      // Check for a valid spike and subsequent decrease
      if ( downswing && ( decreasingCount > 2 ) ) 
      {

    for ( int i = 0; i < 10; i++ )
    {
      currentIndex = (bufferIndex - i + BUFFER_SIZE) % BUFFER_SIZE;
      prevIndex = (currentIndex - 1 + BUFFER_SIZE) % BUFFER_SIZE;

      Serial.print( myc );
      Serial.print( ", " );
      Serial.print( i );
      Serial.print( ", " );
      Serial.print( currentIndex );
      Serial.print( ", " );
      Serial.print( prevIndex );
      Serial.print( ", " );
      Serial.print(   
        sqrt( ( buffer[currentIndex].x * buffer[currentIndex].x ) +
             ( buffer[currentIndex].y * buffer[currentIndex].y ) +
                              ( buffer[currentIndex].z * buffer[currentIndex].z) ) );

      Serial.print( ", " );

      Serial.print(   
        sqrt(buffer[prevIndex].x * buffer[prevIndex].x +
                          buffer[prevIndex].y * buffer[prevIndex].y +
                          buffer[prevIndex].z * buffer[prevIndex].z) );

      Serial.print( ", " );
      Serial.println( tapDetectedInSample );
      Serial.println( "" );
    }


        tapDetectedInSample = true;
        break;  // Exit the loop after detecting a valid tap
      }
    }

  }
}

void AccelSensor::loop()
{
  sampleData();

  lis.read();      // get X Y and Z data at once
  // Then print out the raw data
  Serial.print("X:  "); Serial.print(lis.x);
  Serial.print("  \tY:  "); Serial.print(lis.y);
  Serial.print("  \tZ:  "); Serial.print(lis.z);

  /* Or....get a new sensor event, normalized */
  sensors_event_t event;
  lis.getEvent(&event);

  /* Display the results (acceleration is measured in m/s^2) */
  Serial.print("\t\tX: "); Serial.print(event.acceleration.x);
  Serial.print(" \tY: "); Serial.print(event.acceleration.y);
  Serial.print(" \tZ: "); Serial.print(event.acceleration.z);
  Serial.println(" m/s^2 ");



  uint8_t click = lis.getClick();
  if (click == 0) return;


}

