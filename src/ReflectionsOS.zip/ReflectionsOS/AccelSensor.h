/*
 Reflections, mobile connected entertainment device

 Repository is at https://github.com/frankcohen/ReflectionsOS
 Includes board wiring directions, server side components, examples, support

 Licensed under GPL v3 Open Source Software
 (c) Frank Cohen, All rights reserved. fcohen@starlingwatch.com
 Read the license in the license.txt file that comes with this code.
*/

#ifndef ACCEL_SENSOR_H
#define ACCEL_SENSOR_H

#include "config.h"
#include "secrets.h"

#include "Storage.h"
#include "Haptic.h"
#include "Utils.h"
#include "Logger.h"

#include <Adafruit_LIS3DH.h>
#include <Adafruit_Sensor.h>

#include <Wire.h>
#include "SD.h"
#include "SPI.h"

#include <Kalman.h>

extern Haptic haptic;
extern Utils utils;
extern LOGGER logger;

// Adjust this number for the sensitivity of the 'click' force
// this strongly depend on the range! for 16G, try 5-10
// for 8G, try 10-20. for 4G try 20-40. for 2G try 40-80
#define CLICKTHRESHHOLD 20





#define TAP_DELTA_THRESHOLD 0.2      // Minimum change in acceleration to detect a tap
#define TAP_COOLDOWN 500             // Cooldown between taps to prevent false positives (in ms)
#define DOUBLE_TAP_WINDOW 300        // Time window to detect double tap (in ms)
#define SAMPLE_TIME 2000             // Sample time for accelerometer data (2 seconds)
#define QUIET_TIME_AFTER_TAP 1000    // Time to wait after detecting a tap (1 second)
#define  numRecentSamples 10         // Check the most recent 10 samples

#define BUFFER_SIZE 100         // Number of samples to store (10 seconds if sampling every 100ms)
#define SAMPLE_INTERVAL 100     // Time between samples in milliseconds

class AccelSensor
{
  public:
    AccelSensor();
    void begin();
    void loop();

    bool tapped();
    bool doubletapped();

    // Support methods for other classes
    float getXreading();

  private:
    void sampleData();
    void runGestureSensing();
    void detectTapAndDoubleTap();
    void detectTapFromBuffer();


    // Cyclic buffer to store accelerometer readings
    struct AccelReading {
      float x;
      float y;
      float z;
    };
  
    AccelReading buffer[BUFFER_SIZE];
    int bufferIndex;  // Index to track the current position in the buffer

    // Variables for tap detection
    unsigned long lastTapTime;
    bool doubleTapDetected;
    bool tapDetectedInSample;
    bool gestureDetected;

    unsigned long lastSampleTime;

    // Methods to handle gesture detection
    void clearBuffer();
    void invalidateTapIfGestureDetected();

    int myc;

};

#endif // ACCEL_SENSOR_H
