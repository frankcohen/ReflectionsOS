#include "Experience_Pensive.h"
#include <math.h>

#include "Video.h"
extern Arduino_GFX* gfx;

Experience_Pensive::Experience_Pensive() {}

void Experience_Pensive::begin()
{
  _active = true;
  lastMs_ = millis();

  wellX_ = targetWellX_ = kCX;
  wellY_ = targetWellY_ = kCY;

  tiltX_ = tiltY_ = tiltMag_ = 0.0f;

  gfx->fillScreen(kBg);

  seedParticles_();
}

void Experience_Pensive::teardown()
{
  _active = false;
  // Optional clear:
  // gfx->fillScreen(kBg);
}

void Experience_Pensive::loop()
{
  if (!_active) return;

  uint32_t now = millis();
  uint32_t dms = now - lastMs_;
  lastMs_ = now;

  float dt = clampf_(dms / 16.666f, 0.5f, 2.0f);

  readTilt_();
  updateWellFromTilt_();
  stepParticles_(dt);
  render_();
}

// ------------------------------------------------------------
// Tilt + Well
// ------------------------------------------------------------

float Experience_Pensive::applyDeadZone_(float v, float dz)
{
  float av = fabsf(v);
  if (av < dz) return 0.0f;

  float sign = (v < 0) ? -1.0f : 1.0f;
  float out = (av - dz) / (1.0f - dz);
  return sign * clampf_(out, 0.0f, 1.0f);
}

void Experience_Pensive::readTilt_()
{
  // Your requested API
  float ax = accel.getXreading();
  float ay = accel.getYreading();

  // Normalize to approx [-1..+1] based on your prior -6..+6 usage
  float nx = clampf_(ax / 6.0f, -1.0f, 1.0f);
  float ny = clampf_(ay / 6.0f, -1.0f, 1.0f);

  // Dead-zone to prevent drift when resting
  nx = applyDeadZone_(nx, kTiltDeadZone);
  ny = applyDeadZone_(ny, kTiltDeadZone);

  // If direction feels backwards, flip here:
  // nx = -nx;
  // ny = -ny;

  tiltX_ = nx;
  tiltY_ = ny;

  tiltMag_ = fastLen_(tiltX_, tiltY_);
  tiltMag_ = clampf_(tiltMag_, 0.0f, 1.0f);
}

void Experience_Pensive::updateWellFromTilt_()
{
  float ox = tiltX_ * kWellMaxOffset;
  float oy = tiltY_ * kWellMaxOffset;

  float olen = fastLen_(ox, oy);
  if (olen > kWellMaxOffset)
  {
    float s = kWellMaxOffset / (olen + 0.0001f);
    ox *= s;
    oy *= s;
  }

  targetWellX_ = kCX + ox;
  targetWellY_ = kCY + oy;

  wellX_ = wellX_ + kWellSmooth * (targetWellX_ - wellX_);
  wellY_ = wellY_ + kWellSmooth * (targetWellY_ - wellY_);
}

// ------------------------------------------------------------
// Particles
// ------------------------------------------------------------

void Experience_Pensive::seedParticles_()
{
  for (int i = 0; i < kMaxP; i++)
  {
    p_[i].seed = 0xA341316Cu ^ (i * 2654435761u) ^ millis();
    spawnOne_(i);
  }
}

void Experience_Pensive::spawnOne_(int i)
{
  P &p = p_[i];
  uint32_t &s = p.seed;

  float a = rand01_(s) * 6.2831853f;
  float r = kSpawnRadius + (rand01_(s) - 0.5f) * 10.0f;

  p.x = kCX + cosf(a) * r;
  p.y = kCY + sinf(a) * r;

  float tx = -sinf(a);
  float ty =  cosf(a);
  float v  = 0.8f + rand01_(s) * 1.6f;

  p.vx = tx * v;
  p.vy = ty * v;

  // slight inward nudge
  p.vx += (kCX - p.x) * 0.002f;
  p.vy += (kCY - p.y) * 0.002f;

  p.mass  = 0.75f + rand01_(s) * 1.2f;
  p.alpha = 0.35f + rand01_(s) * 0.55f;

  // bluish mist colors
  uint16_t c1 = 0xFFFF; // white
  uint16_t c2 = 0xCFFF; // pale cyan
  p.color = lerp565_(c2, c1, rand01_(s));

  p.alive = true;
}

void Experience_Pensive::stepParticles_(float dt)
{
  // Swirl strength grows with tilt magnitude
  float swirlStrength = kSwirlBase + tiltMag_ * kSwirlTiltGain;

  // Optional: swirl direction changes with tilt
  // tiltX_ biases CW vs CCW (flip sign if you want opposite)
  float swirlSign = clampf_(tiltX_ * kSwirlDirBias, -1.0f, 1.0f);

  // reduce bias when nearly flat
  if (tiltMag_ < 0.12f)
    swirlSign *= (tiltMag_ / 0.12f);

  float swirl = swirlStrength * swirlSign;

  float G = kBaseG * (1.0f + 0.25f * tiltMag_);

  for (int i = 0; i < kMaxP; i++)
  {
    P &p = p_[i];

    float dx = wellX_ - p.x;
    float dy = wellY_ - p.y;

    float r2 = dx*dx + dy*dy + kSoftening;
    float r  = sqrtf(r2);
    float inv = 1.0f / (r + 0.0001f);

    // inward pull
    float ax = (dx * inv) * (G / p.mass);
    float ay = (dy * inv) * (G / p.mass);

    // tangential
    float tx = -dy * inv;
    float ty =  dx * inv;

    ax += tx * swirl;
    ay += ty * swirl;

    // wobble
    uint32_t s = p.seed;
    float wob = (rand01_(s) - 0.5f) * 0.06f;
    p.seed = s;

    ax += wob * tx;
    ay += wob * ty;

    // integrate
    p.vx += ax * dt;
    p.vy += ay * dt;

    p.vx *= kDrag;
    p.vy *= kDrag;

    float sp = fastLen_(p.vx, p.vy);
    if (sp > kMaxSpeed)
    {
      float ss = kMaxSpeed / (sp + 0.0001f);
      p.vx *= ss;
      p.vy *= ss;
    }

    p.x += p.vx * dt;
    p.y += p.vy * dt;

    // recycle near well
    if (r < kKillRadius)
    {
      spawnOne_(i);
      continue;
    }

    if (p.x < -10 || p.x > kW + 10 || p.y < -10 || p.y > kH + 10)
    {
      spawnOne_(i);
      continue;
    }
  }
}

// ------------------------------------------------------------
// Render
// ------------------------------------------------------------

void Experience_Pensive::render_()
{
  // dither-clear sparse pixels to create trails
  uint32_t t = millis();
  for (int y = 0; y < kH; y += 2)
  {
    for (int x = (y & 2); x < kW; x += 4)
    {
      if (((x + y + (t >> 4)) & 7) == 0)
        gfx->drawPixel(x, y, kBg);
    }
  }

  // well glow
  int wx = (int)wellX_;
  int wy = (int)wellY_;

  gfx->fillCircle(wx, wy, 7, 0xFFFF);
  gfx->drawCircle(wx, wy, 12, 0xCFFF);
  gfx->drawCircle(wx, wy, 18, 0x7DFF);

  // particles
  for (int i = 0; i < kMaxP; i++)
  {
    P &p = p_[i];
    int x = (int)p.x;
    int y = (int)p.y;

    if ((unsigned)x >= kW || (unsigned)y >= kH) continue;

    uint16_t c = p.color;
    // brightness tiers
    // (if you want more “mist”, make these darker)
    // c = 0x7DFF; etc.

    gfx->fillCircle(x, y, kParticleSize, c);

    if (((p.seed + millis()) & 127) == 0)
      gfx->drawPixel(x + 1, y, 0xFFFF);
  }

  // faint spiral hint
  for (int i = 0; i < 14; i++)
  {
    float a = (millis() * 0.00035f) + i * 0.55f;
    float rr = 95.0f - i * 6.0f;

    int sx = (int)(kCX + cosf(a) * rr);
    int sy = (int)(kCY + sinf(a) * rr);

    if ((unsigned)sx < kW && (unsigned)sy < kH)
      gfx->drawPixel(sx, sy, 0x18C3);
  }

  // If you use a canvas buffer, flush here:
  // canvas->flush();
}

// ------------------------------------------------------------
// Helpers
// ------------------------------------------------------------

float Experience_Pensive::rand01_(uint32_t &s)
{
  s ^= s << 13;
  s ^= s >> 17;
  s ^= s << 5;
  return (float)(s & 0x00FFFFFF) / (float)0x01000000;
}

uint16_t Experience_Pensive::lerp565_(uint16_t a, uint16_t b, float t)
{
  t = clampf_(t, 0.0f, 1.0f);

  int ar = (a >> 11) & 31;
  int ag = (a >> 5)  & 63;
  int ab = (a >> 0)  & 31;

  int br = (b >> 11) & 31;
  int bg = (b >> 5)  & 63;
  int bb = (b >> 0)  & 31;

  int rr = (int)(ar + (br - ar) * t);
  int rg = (int)(ag + (bg - ag) * t);
  int rb = (int)(ab + (bb - ab) * t);

  return (uint16_t)((rr << 11) | (rg << 5) | (rb));
}