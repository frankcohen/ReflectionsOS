#pragma once

#include <Arduino.h>

// These two are the likely correct project headers.
// If one of these doesn't exist in your tree, swap it for the file where
// your Experience base class + ExperienceName enum are defined.
#include "Experience.h"
#include "ExperienceService.h"

// Pull in your real accel class header so accel is a known type.
#include "AccelSensor.h"
extern AccelSensor accel;

class Experience_Pensive : public Experience
{
public:
  Experience_Pensive();

  // NOTE: no override keywords here because your base class signatures differ
  void begin();
  void loop();
  void teardown();

  // If your base class expects a name/id function, keep this,
  // but it requires ExperienceName to be defined by includes above.
  ExperienceName getName() { return Pensive; }

private:
  // -------------------------
  // Tunables
  // -------------------------
  static constexpr int   kW  = 240;
  static constexpr int   kH  = 240;
  static constexpr int   kCX = 120;
  static constexpr int   kCY = 120;

  static constexpr uint16_t kBg = 0x0000; // BLACK

  static constexpr int   kMaxP = 48;

  static constexpr float kDrag       = 0.985f;
  static constexpr float kBaseG      = 0.38f;
  static constexpr float kSoftening  = 90.0f;
  static constexpr float kSpawnRadius = 110.0f;
  static constexpr float kKillRadius  = 10.0f;
  static constexpr float kMaxSpeed    = 5.0f;

  static constexpr float kWellMaxOffset = 55.0f;
  static constexpr float kWellSmooth    = 0.07f;

  // Dead-zone for tilt (normalized)
  static constexpr float kTiltDeadZone = 0.06f;

  // Swirl changes with tilt
  static constexpr float kSwirlBase     = 0.55f;
  static constexpr float kSwirlTiltGain = 0.55f;
  static constexpr float kSwirlDirBias  = 0.85f;

  static constexpr int kParticleSize = 2;

  struct P
  {
    float x, y;
    float vx, vy;
    float mass;
    float alpha;
    uint16_t color;
    uint32_t seed;
    bool alive;
  };

  P p_[kMaxP];

  bool _active = false;

  float wellX_ = kCX;
  float wellY_ = kCY;
  float targetWellX_ = kCX;
  float targetWellY_ = kCY;

  float tiltX_ = 0.0f;
  float tiltY_ = 0.0f;
  float tiltMag_ = 0.0f;

  uint32_t lastMs_ = 0;

private:
  void seedParticles_();
  void spawnOne_(int i);

  void readTilt_();
  void updateWellFromTilt_();

  void stepParticles_(float dt);
  void render_();

  static float clampf_(float v, float lo, float hi) { return (v < lo) ? lo : (v > hi) ? hi : v; }
  static float fastLen_(float x, float y) { return sqrtf(x*x + y*y); }
  static float applyDeadZone_(float v, float dz);

  static float rand01_(uint32_t &s);
  static uint16_t lerp565_(uint16_t a, uint16_t b, float t);
};